<?php $__env->startSection('content'); ?>

    <div style="position: relative; top:10%; text-align: center;">
        <h1>Productos</h1>
    </div>
    <a href="<?php echo e(route('productos.create')); ?>" class="btn btn-info" style="position: fixed; bottom: 40px; right:40px; font-size:24px;"> + Agregar</a>
    <br><br>

    <?php if(count($lista)>0): ?>

        <div class="row" style="text-align: center;">
            <div class="col-2">
                <h3>Categoria</h3>
            </div>
            <div class="col-6">
                <h3>Producto</h3>
            </div>
            <div class="col-2">
                <h3>Cantidad</h3>
            </div>
            <div class="col-2">
                <h3>Precio</h3>
            </div>
        </div>

        <?php $__currentLoopData = $lista; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="row" style="text-align: center;">
            <div class="col-2">
               <p><?php echo e($Producto->categoria); ?></p>
            </div>
            <div class="col-6">
                <p><?php echo e($Producto->nombre); ?> -<?php echo e($Producto->descripcion); ?> - <?php echo e($Producto->marca); ?></p>
            </div>
            <div class="col-2">
                <p><?php echo e($Producto->cantidad); ?></p>
            </div>
            <div class="col-2">
                <p>$ <?php echo e($Producto->precio); ?></p>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php else: ?>
    <p style="text-align: center;">No hay productos registrados. Agrega productos dando click en el boton "+" para agregar</p>
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tienda\resources\views/pages/admin/productos/index.blade.php ENDPATH**/ ?>