<?php $__env->startSection('content'); ?>
    <div style="position: relative; top 40%; left: 40%">
        <h1> Bienvenido <?php echo e(Auth::user()->nombre); ?> </h1>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tienda\resources\views/pages/admin/index.blade.php ENDPATH**/ ?>